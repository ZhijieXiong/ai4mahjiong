from player import response


if __name__ == "__main__":
    response()
